# IBMQuantumChallenge-Africa2021
My lab solutions for the IBM Quantum Challenge - Africa 9 - 21 September 2021

# Lab 1 Agriculture
## Crop-Yield 
Solve a simple agricultural optimization problem on the choice of crops for a farm, with the goal of increasing the yield. This lab focuses on access to food, an important problem for Africa.

# Lab 2 Finance
## Quantum Speedups in Finance
There is significant promise in applying quantum computing to the field of finance. One important financial computation is predicting the future price of derivative contracts, or options. The dynamics of the African financial markets are complicated and different to the rest of the world, increasing the complexity of models for predictions in this field. Construct a model for a QuantumTech share and calculate its expected value over a certain number of days, using both classical and quantum approaches.

# Lab 3 Healthcare
## Quantum Chemistry for HIV
HIV has affected many communities, especially in Africa. Though there has been significant research into treatments for the disease, there is still a lot of work to be done. Quantum computers have the promise of revolutionising the way we discover drugs and how we treat illnesses. 
Demo calculating whether a given drug would block the binding ability of the viral protein. Using advanced quantum algorithms and cutting-edge research, model and simulate the molecular interaction between the virus and a hypothetical drug.
